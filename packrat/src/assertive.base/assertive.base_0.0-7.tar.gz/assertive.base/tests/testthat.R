library(testthat)
library(assertive.base)

test_check("assertive.base")
