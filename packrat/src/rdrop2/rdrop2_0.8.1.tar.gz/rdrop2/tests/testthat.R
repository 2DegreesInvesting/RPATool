library(testthat)
library(rdrop2)

test_check("rdrop2")
