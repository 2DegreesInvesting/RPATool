library(testthat)
library(assertive.numbers)

test_check("assertive.numbers")
