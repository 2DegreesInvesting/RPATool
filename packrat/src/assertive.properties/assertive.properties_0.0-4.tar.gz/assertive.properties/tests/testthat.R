library(testthat)
library(assertive.base)
library(assertive.properties)

test_check("assertive.properties")

