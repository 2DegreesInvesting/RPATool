library(testthat)
library(assertive.base)
library(assertive.strings)

test_check("assertive.strings")
