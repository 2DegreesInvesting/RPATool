library(testthat)
library(assertive.types)

test_check("assertive.types")
