library(testthat)
library(assertive.sets)

test_check("assertive.sets")
