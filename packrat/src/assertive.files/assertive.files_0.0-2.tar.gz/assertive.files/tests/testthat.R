library(testthat)
library(assertive.files)

test_check("assertive.files")

